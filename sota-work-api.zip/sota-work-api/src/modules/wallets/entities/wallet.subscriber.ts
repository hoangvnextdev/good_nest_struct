import { Connection, EntitySubscriberInterface, InsertEvent } from 'typeorm';
import { Injectable, Logger } from '@nestjs/common';
import { InjectConnection } from '@nestjs/typeorm';
import { Wallet } from './wallet.entity';
@Injectable()
export class WalletSubscriber implements EntitySubscriberInterface<Wallet> {
  private readonly logger = new Logger(WalletSubscriber.name);
  constructor(@InjectConnection() readonly connection: Connection) {
    connection.subscribers.push(this);
  }

  listenTo() {
    return Wallet;
  }

  async afterInsert(event: InsertEvent<Wallet>) {
    // do something you like
  }
}
