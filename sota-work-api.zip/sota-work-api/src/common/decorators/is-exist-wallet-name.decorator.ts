import {
  registerDecorator,
  ValidationArguments,
  ValidationOptions,
  ValidatorConstraint,
  ValidatorConstraintInterface,
} from 'class-validator';
import { Injectable } from '@nestjs/common';
import { WalletsRepository } from 'src/modules/wallets/wallets.repository';

@ValidatorConstraint({ async: true })
@Injectable()
export class IsWalletNameAlreadyExistConstraint
  implements ValidatorConstraintInterface {
  constructor(private readonly walletsRepository: WalletsRepository) {}

  async validate(name: any, args: ValidationArguments) {
    const wallet = await this.walletsRepository.findOne({ name });
    return !wallet;
  }

  defaultMessage(args: ValidationArguments) {
    return 'Wallet Name Is Existed!';
  }
}

export function IsExistWalletName(validationOptions?: ValidationOptions) {
  // eslint-disable-next-line @typescript-eslint/ban-types
  return function (object: Object, propertyName: string) {
    registerDecorator({
      target: object.constructor,
      propertyName: propertyName,
      options: validationOptions,
      constraints: [],
      validator: IsWalletNameAlreadyExistConstraint,
    });
  };
}
