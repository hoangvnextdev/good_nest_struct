
export default () => ({
  port: parseInt(process.env.PORT, 10) || 3000,
  database: {
    connection: process.env.DB_CONNECTION || 'mysql',
    host: process.env.DB_HOST,
    port: parseInt(process.env.DB_PORT, 10) || 3306,
    userName: process.env.DB_USER_NAME,
    password: process.env.DB_PASSWORD,
    name: process.env.DB_NAME,
  },
  redis: {
    host: process.env.REDIS_HOST || 'localhost',
    port: parseInt(process.env.REDIS_PORT) || 6379,
  },
});
