import { Seeder, Factory } from 'typeorm-seeding';

import { Connection } from 'typeorm';
import { Wallet } from 'src/modules/wallets/entities/wallet.entity';

export default class CreateUsers implements Seeder {
  public async run(factory: Factory, connection: Connection): Promise<any> {
    await factory(Wallet)().createMany(10);
  }
}
