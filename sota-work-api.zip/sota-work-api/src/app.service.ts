import { Injectable } from '@nestjs/common';

@Injectable()
export class AppService {
  healCheck(): string {
    return 'Server Is Fine!';
  }
}
