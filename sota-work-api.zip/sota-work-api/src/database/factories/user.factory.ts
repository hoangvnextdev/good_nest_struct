import { Wallet } from 'src/modules/wallets/entities/wallet.entity';
import { define } from 'typeorm-seeding';

define(Wallet, (faker: any) => {
  const wallet = new Wallet();
  wallet.name = faker.random.word();
  return wallet;
});
