import { ApiProperty } from '@nestjs/swagger';
import { IsNumber, IsOptional, Max, Min } from 'class-validator';
import { Transform } from 'class-transformer';

export class PagingDto {
  @ApiProperty({ default: 1, required: false })
  @Transform((page) => parseInt(page.value))
  @IsOptional()
  @IsNumber()
  @Min(1)
  page: number;

  @ApiProperty({ default: 1, required: false })
  @Transform((limit) => parseInt(limit.value))
  @IsOptional()
  @IsNumber()
  @Min(1)
  @Max(100)
  limit: number;
}
