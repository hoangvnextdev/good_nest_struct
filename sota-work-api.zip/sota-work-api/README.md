

## Descriptions

Project Sota API Market Base On

[Nest](https://github.com/nestjs/nest) framework TypeScript starter repository.

## First Time Installation

```bash
# start docker 
$ docker-compose up -d --build

# install node_modules inside docker 
$ docker-compose exec back bash && npm i

# run migrations
$ npm run migration:run

# run seeds to fake data
$ npm run seed:config && npm run seed:run

# finally run server !!!!!
$ npm run start:dev

# Debug Mode
$ npm run start:debug

```

## Running the app inside docker 

```bash
# development
$ npm run start

# watch mode
$ npm run start:dev

# production mode
$ npm run start:prod

# add migration file

$ npx typeorm migration:generate -n addWalletTable

```

## Test

```bash
# unit tests
$ npm run test

# e2e tests
$ npm run test:e2e

# test coverage
$ npm run test:cov
```

