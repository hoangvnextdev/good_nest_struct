import { MigrationInterface, QueryRunner } from 'typeorm';

export class addWalletTable1612261576808 implements MigrationInterface {
  name = 'addWalletTable1612261576808';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      'CREATE TABLE `wallet` (`id` int NOT NULL AUTO_INCREMENT, `name` varchar(255) NULL, `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, PRIMARY KEY (`id`)) ENGINE=InnoDB',
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query('DROP TABLE `wallet`');
  }
}
