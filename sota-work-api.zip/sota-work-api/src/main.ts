import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';

import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { TransformInterceptor } from './common/interceptors/transform-response';
import { HttpExceptionFilter } from './common/exceptions/http-exception.filter';
import { useContainer, ValidationError } from 'class-validator';
import { ValidationPipe, BadRequestException } from '@nestjs/common';
import { normalizeValidationError } from './common/utility/exception.utility';
import * as winston from 'winston';
import {
  utilities as nestWinstonModuleUtilities,
  WinstonModule,
} from 'nest-winston';
import { ConfigService } from '@nestjs/config';
async function bootstrap() {
  // Step Logger
  const app = await NestFactory.create(AppModule, {
    logger: WinstonModule.createLogger({
      format: winston.format.combine(
        winston.format.splat(), // Necessary to produce the 'meta' property
        winston.format.simple(),
      ),
      // options
      transports: [
        new winston.transports.File({
          filename: 'application-error.log',
          level: 'error',
        }),
        new winston.transports.File({
          filename: 'application-debug.log',
          level: 'debug',
        }),
        new winston.transports.Console({
          format: winston.format.combine(
            winston.format.timestamp(),
            nestWinstonModuleUtilities.format.nestLike(),
          ),
        }),
      ],
    }),
  });
  // Setup Swagger
  const options = new DocumentBuilder()
    .setTitle('Vnext Wallet Service')
    .setDescription('The Market Service API description')
    .setVersion('1.0')
    .addBearerAuth()
    .build();
  const document = SwaggerModule.createDocument(app, options);

  SwaggerModule.setup('docs', app, document);
  // Global Validation Custom
  app.useGlobalPipes(
    new ValidationPipe({
      transform: true,
      exceptionFactory: (errors: ValidationError[]) => {
        if (errors.length > 0)
          throw new BadRequestException(normalizeValidationError(errors));
      },
    }),
  );
  // Response Transformer Mapping
  app.useGlobalInterceptors(new TransformInterceptor());
  // HttpException custom
  app.useGlobalFilters(new HttpExceptionFilter());
  // Start API Server
  const configService = app.get(ConfigService);
  useContainer(app.select(AppModule), { fallbackOnErrors: true });
  await app.listen(configService.get('port'));
}

bootstrap();
