export const FilesOptions = {
  maxSize: 3e7,
  allowFileType: ['jpg', 'png', 'jpeg'],
};
