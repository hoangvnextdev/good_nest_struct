import { CacheModule, Module } from '@nestjs/common';
import { WalletsService } from './wallets.service';
import { WalletsController } from './wallets.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { WalletsRepository } from './wallets.repository';
import { IsWalletNameAlreadyExistConstraint } from 'src/common/decorators/is-exist-wallet-name.decorator';
import { WalletSubscriber } from './entities/wallet.subscriber';
import { ConfigModule, ConfigService } from '@nestjs/config';
import * as redisStore from 'cache-manager-redis-store';

@Module({
  imports: [
    TypeOrmModule.forFeature([WalletsRepository]),
    CacheModule.registerAsync({
      imports: [ConfigModule],
      useFactory: (configService: ConfigService) => ({
        store: redisStore,
        host: configService.get('redis.host'),
        port: configService.get('redis.port'),
      }),
      inject: [ConfigService],
    }),
  ],

  controllers: [WalletsController],
  providers: [
    WalletSubscriber,
    WalletsService,
    IsWalletNameAlreadyExistConstraint,
  ],
})
export class WalletsModule {}
