import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { WalletsModule } from './modules/wallets/wallets.module';
import configuration from './config/configuration';
import { Wallet } from './modules/wallets/entities/wallet.entity';
import { WalletSubscriber } from './modules/wallets/entities/wallet.subscriber';

@Module({
  imports: [
    ConfigModule.forRoot({
      envFilePath: '.env.development',
      expandVariables: true,
      load: [configuration],
      isGlobal: true,
    }),
    TypeOrmModule.forRootAsync({
      imports: [ConfigModule],
      useFactory: (configService: ConfigService) => ({
        type: 'mysql',
        host: configService.get('database.host'),
        port: configService.get('database.port'),
        username: configService.get('database.userName'),
        password: configService.get('database.password'),
        database: configService.get('database.name'),
        entities: [Wallet],
        subscribers: [WalletSubscriber],
        synchronize: false,
      }),
      inject: [ConfigService],
    }),
    WalletsModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
