import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString, MaxLength, MinLength } from 'class-validator';
import { IsExistWalletName } from 'src/common/decorators/is-exist-wallet-name.decorator';

export class CreateWalletDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @MinLength(5)
  @MaxLength(255)
  @IsExistWalletName()
  name: string;
}
