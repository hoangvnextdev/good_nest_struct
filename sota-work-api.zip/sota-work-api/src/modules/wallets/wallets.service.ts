import { CACHE_MANAGER, Inject, Injectable } from '@nestjs/common';
import { CreateWalletDto } from './dto/create-wallet.dto';
import { UpdateWalletDto } from './dto/update-wallet.dto';
import { WalletsRepository } from './wallets.repository';
import { Cache } from 'cache-manager';

import {
  IPaginationOptions,
  paginate,
  Pagination,
} from 'nestjs-typeorm-paginate';
import { Wallet } from './entities/wallet.entity';
import { classToPlain, plainToClass } from 'class-transformer';
@Injectable()
export class WalletsService {
  constructor(
    private readonly walletsRepository: WalletsRepository,
    @Inject(CACHE_MANAGER) private cacheManager: Cache,
  ) {}
  create(createWalletDto: CreateWalletDto) {
    return this.walletsRepository.insert(createWalletDto);
  }

  findAll(options: IPaginationOptions): Promise<Pagination<Wallet>> {
    const $query = this.walletsRepository
      .createQueryBuilder('wallet')
      .orderBy('wallet.updatedAt', 'DESC');
    return paginate<Wallet>($query, options);
  }

  async findOne(id: number) {
    // try cached response
    const cachedKey = `wallet_${id}`;
    // delete cache
    await this.cacheManager.del(cachedKey);
    const cachedData: string = await this.cacheManager.get(cachedKey);
    if (!cachedData) {
      // get data then return
      const dataFromDB = await this.walletsRepository.findOne({ id });
      const jsonData = JSON.stringify(classToPlain(dataFromDB));
      this.cacheManager.set(cachedKey, jsonData, { ttl: 1000 });
      return dataFromDB;
    }
    return plainToClass(Wallet, JSON.parse(cachedData));
  }

  update(id: number, updateWalletDto: UpdateWalletDto) {
    return this.walletsRepository.update(id, updateWalletDto);
  }

  remove(id: number) {
    return this.walletsRepository.delete(id);
  }
}
